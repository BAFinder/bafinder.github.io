#!/bin/sh
/Users/josh/Downloads/BART_macosx/Contents/MacOS/BART_macosx lib=/Users/josh/Downloads/test_data/lib.txt gradient=/Users/josh/Downloads/test_data/gradient.txt ref=/Users/josh/Downloads/test_data/caliRT.txt output=/Users/josh/Downloads/test_data/predictedRT.txt
